﻿namespace w03_appdev
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.lb_balance_mainmenu = new System.Windows.Forms.Label();
            this.lb_quantity_menu = new System.Windows.Forms.Label();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.pnl_mainmenu = new System.Windows.Forms.Panel();
            this.btn_logout_mainmenu = new System.Windows.Forms.Button();
            this.pnl_deposit = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_logout_deposit = new System.Windows.Forms.Button();
            this.btn_deposit_deposit = new System.Windows.Forms.Button();
            this.lb_quantity_deposit = new System.Windows.Forms.Label();
            this.lb_balance_deposit = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.pnl_withdraw = new System.Windows.Forms.Panel();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_logout_withdraw = new System.Windows.Forms.Button();
            this.btn_withdraw_withdraw = new System.Windows.Forms.Button();
            this.lb_quantity_withdraw = new System.Windows.Forms.Label();
            this.lb_balance_withdraw = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnl_mainmenu.SuspendLayout();
            this.pnl_deposit.SuspendLayout();
            this.pnl_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(77, 46);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(241, 59);
            this.lb_ucbank.TabIndex = 1;
            this.lb_ucbank.Text = "UC Bank";
            // 
            // lb_balance_mainmenu
            // 
            this.lb_balance_mainmenu.AutoSize = true;
            this.lb_balance_mainmenu.Location = new System.Drawing.Point(85, 190);
            this.lb_balance_mainmenu.Name = "lb_balance_mainmenu";
            this.lb_balance_mainmenu.Size = new System.Drawing.Size(67, 20);
            this.lb_balance_mainmenu.TabIndex = 2;
            this.lb_balance_mainmenu.Text = "Balance";
            // 
            // lb_quantity_menu
            // 
            this.lb_quantity_menu.AutoSize = true;
            this.lb_quantity_menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_quantity_menu.Location = new System.Drawing.Point(179, 180);
            this.lb_quantity_menu.Name = "lb_quantity_menu";
            this.lb_quantity_menu.Size = new System.Drawing.Size(129, 32);
            this.lb_quantity_menu.TabIndex = 3;
            this.lb_quantity_menu.Text = "Rp. 0,00";
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(131, 242);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(110, 42);
            this.btn_deposit.TabIndex = 4;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(132, 301);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(110, 42);
            this.btn_withdraw.TabIndex = 5;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // pnl_mainmenu
            // 
            this.pnl_mainmenu.Controls.Add(this.btn_logout_mainmenu);
            this.pnl_mainmenu.Controls.Add(this.btn_withdraw);
            this.pnl_mainmenu.Controls.Add(this.btn_deposit);
            this.pnl_mainmenu.Controls.Add(this.lb_quantity_menu);
            this.pnl_mainmenu.Controls.Add(this.lb_balance_mainmenu);
            this.pnl_mainmenu.Controls.Add(this.lb_ucbank);
            this.pnl_mainmenu.Location = new System.Drawing.Point(22, 50);
            this.pnl_mainmenu.Name = "pnl_mainmenu";
            this.pnl_mainmenu.Size = new System.Drawing.Size(406, 373);
            this.pnl_mainmenu.TabIndex = 6;
            // 
            // btn_logout_mainmenu
            // 
            this.btn_logout_mainmenu.Location = new System.Drawing.Point(274, 120);
            this.btn_logout_mainmenu.Name = "btn_logout_mainmenu";
            this.btn_logout_mainmenu.Size = new System.Drawing.Size(110, 42);
            this.btn_logout_mainmenu.TabIndex = 5;
            this.btn_logout_mainmenu.Text = "Log  out";
            this.btn_logout_mainmenu.UseVisualStyleBackColor = true;
            this.btn_logout_mainmenu.Click += new System.EventHandler(this.btn_logout_mainmenu_Click);
            // 
            // pnl_deposit
            // 
            this.pnl_deposit.Controls.Add(this.tb_deposit);
            this.pnl_deposit.Controls.Add(this.label4);
            this.pnl_deposit.Controls.Add(this.btn_logout_deposit);
            this.pnl_deposit.Controls.Add(this.btn_deposit_deposit);
            this.pnl_deposit.Controls.Add(this.lb_quantity_deposit);
            this.pnl_deposit.Controls.Add(this.lb_balance_deposit);
            this.pnl_deposit.Controls.Add(this.label3);
            this.pnl_deposit.Location = new System.Drawing.Point(457, 50);
            this.pnl_deposit.Name = "pnl_deposit";
            this.pnl_deposit.Size = new System.Drawing.Size(406, 373);
            this.pnl_deposit.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(114, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Input Deposit Amount";
            // 
            // btn_logout_deposit
            // 
            this.btn_logout_deposit.Location = new System.Drawing.Point(274, 105);
            this.btn_logout_deposit.Name = "btn_logout_deposit";
            this.btn_logout_deposit.Size = new System.Drawing.Size(110, 42);
            this.btn_logout_deposit.TabIndex = 5;
            this.btn_logout_deposit.Text = "Log  out";
            this.btn_logout_deposit.UseVisualStyleBackColor = true;
            this.btn_logout_deposit.Click += new System.EventHandler(this.btn_logout_mainmenu_Click);
            // 
            // btn_deposit_deposit
            // 
            this.btn_deposit_deposit.Location = new System.Drawing.Point(139, 301);
            this.btn_deposit_deposit.Name = "btn_deposit_deposit";
            this.btn_deposit_deposit.Size = new System.Drawing.Size(110, 42);
            this.btn_deposit_deposit.TabIndex = 4;
            this.btn_deposit_deposit.Text = "Deposit";
            this.btn_deposit_deposit.UseVisualStyleBackColor = true;
            // 
            // lb_quantity_deposit
            // 
            this.lb_quantity_deposit.AutoSize = true;
            this.lb_quantity_deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_quantity_deposit.Location = new System.Drawing.Point(179, 169);
            this.lb_quantity_deposit.Name = "lb_quantity_deposit";
            this.lb_quantity_deposit.Size = new System.Drawing.Size(129, 32);
            this.lb_quantity_deposit.TabIndex = 3;
            this.lb_quantity_deposit.Text = "Rp. 0,00";
            // 
            // lb_balance_deposit
            // 
            this.lb_balance_deposit.AutoSize = true;
            this.lb_balance_deposit.Location = new System.Drawing.Point(85, 179);
            this.lb_balance_deposit.Name = "lb_balance_deposit";
            this.lb_balance_deposit.Size = new System.Drawing.Size(67, 20);
            this.lb_balance_deposit.TabIndex = 2;
            this.lb_balance_deposit.Text = "Balance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(77, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(241, 59);
            this.label3.TabIndex = 1;
            this.label3.Text = "UC Bank";
            // 
            // tb_deposit
            // 
            this.tb_deposit.Location = new System.Drawing.Point(98, 258);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(196, 26);
            this.tb_deposit.TabIndex = 7;
            // 
            // pnl_withdraw
            // 
            this.pnl_withdraw.Controls.Add(this.tb_withdraw);
            this.pnl_withdraw.Controls.Add(this.label5);
            this.pnl_withdraw.Controls.Add(this.btn_logout_withdraw);
            this.pnl_withdraw.Controls.Add(this.btn_withdraw_withdraw);
            this.pnl_withdraw.Controls.Add(this.lb_quantity_withdraw);
            this.pnl_withdraw.Controls.Add(this.lb_balance_withdraw);
            this.pnl_withdraw.Controls.Add(this.label8);
            this.pnl_withdraw.Location = new System.Drawing.Point(895, 50);
            this.pnl_withdraw.Name = "pnl_withdraw";
            this.pnl_withdraw.Size = new System.Drawing.Size(406, 373);
            this.pnl_withdraw.TabIndex = 8;
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Location = new System.Drawing.Point(98, 258);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(196, 26);
            this.tb_withdraw.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(114, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Input Withdraw Amount";
            // 
            // btn_logout_withdraw
            // 
            this.btn_logout_withdraw.Location = new System.Drawing.Point(274, 105);
            this.btn_logout_withdraw.Name = "btn_logout_withdraw";
            this.btn_logout_withdraw.Size = new System.Drawing.Size(110, 42);
            this.btn_logout_withdraw.TabIndex = 5;
            this.btn_logout_withdraw.Text = "Log  out";
            this.btn_logout_withdraw.UseVisualStyleBackColor = true;
            this.btn_logout_withdraw.Click += new System.EventHandler(this.btn_logout_mainmenu_Click);
            // 
            // btn_withdraw_withdraw
            // 
            this.btn_withdraw_withdraw.Location = new System.Drawing.Point(139, 301);
            this.btn_withdraw_withdraw.Name = "btn_withdraw_withdraw";
            this.btn_withdraw_withdraw.Size = new System.Drawing.Size(110, 42);
            this.btn_withdraw_withdraw.TabIndex = 4;
            this.btn_withdraw_withdraw.Text = "Withdraw";
            this.btn_withdraw_withdraw.UseVisualStyleBackColor = true;
            // 
            // lb_quantity_withdraw
            // 
            this.lb_quantity_withdraw.AutoSize = true;
            this.lb_quantity_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_quantity_withdraw.Location = new System.Drawing.Point(179, 169);
            this.lb_quantity_withdraw.Name = "lb_quantity_withdraw";
            this.lb_quantity_withdraw.Size = new System.Drawing.Size(129, 32);
            this.lb_quantity_withdraw.TabIndex = 3;
            this.lb_quantity_withdraw.Text = "Rp. 0,00";
            // 
            // lb_balance_withdraw
            // 
            this.lb_balance_withdraw.AutoSize = true;
            this.lb_balance_withdraw.Location = new System.Drawing.Point(85, 179);
            this.lb_balance_withdraw.Name = "lb_balance_withdraw";
            this.lb_balance_withdraw.Size = new System.Drawing.Size(67, 20);
            this.lb_balance_withdraw.TabIndex = 2;
            this.lb_balance_withdraw.Text = "Balance";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(77, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(241, 59);
            this.label8.TabIndex = 1;
            this.label8.Text = "UC Bank";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 839);
            this.Controls.Add(this.pnl_withdraw);
            this.Controls.Add(this.pnl_deposit);
            this.Controls.Add(this.pnl_mainmenu);
            this.Name = "Form2";
            this.Text = "Form2";
            this.pnl_mainmenu.ResumeLayout(false);
            this.pnl_mainmenu.PerformLayout();
            this.pnl_deposit.ResumeLayout(false);
            this.pnl_deposit.PerformLayout();
            this.pnl_withdraw.ResumeLayout(false);
            this.pnl_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Label lb_balance_mainmenu;
        private System.Windows.Forms.Label lb_quantity_menu;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Panel pnl_mainmenu;
        private System.Windows.Forms.Button btn_logout_mainmenu;
        private System.Windows.Forms.Panel pnl_deposit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_logout_deposit;
        private System.Windows.Forms.Button btn_deposit_deposit;
        private System.Windows.Forms.Label lb_quantity_deposit;
        private System.Windows.Forms.Label lb_balance_deposit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Panel pnl_withdraw;
        private System.Windows.Forms.TextBox tb_withdraw;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_logout_withdraw;
        private System.Windows.Forms.Button btn_withdraw_withdraw;
        private System.Windows.Forms.Label lb_quantity_withdraw;
        private System.Windows.Forms.Label lb_balance_withdraw;
        private System.Windows.Forms.Label label8;
    }
}