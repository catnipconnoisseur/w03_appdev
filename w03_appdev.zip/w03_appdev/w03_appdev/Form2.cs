﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace w03_appdev
{
    public partial class Form2 : Form
    {
        DataTable dt;
        string username;
        string password;
        long saldo;

        public Form2()
        {
            InitializeComponent();
        }

        private void btn_logout_mainmenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            pnl_deposit.Visible = true;
            pnl_mainmenu.Visible = false;

            if (tb_deposit.Text.Length > 0 && long.TryParse(tb_deposit.Text, out _) && Convert.ToInt64(tb_deposit.Text) > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row["Username"].ToString() == Name)
                    {
                        row["Balance"] = Convert.ToInt64(row["Balance"]) + Convert.ToInt64(tb_deposit.Text);
                        ((List<string>)row["BalanceHis"]).Add("+ " + tb_deposit.Text);
                        //balanceReset();
                    }
                }
            }
            else
            {
                if (tb_deposit.Text.Length == 0 || !long.TryParse(tb_deposit.Text, out long value) || Convert.ToInt64(tb_deposit.Text) < 1)
                {
                    MessageBox.Show("Please Input Valid Amount");
                }
            }
            tb_deposit.Clear();
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            pnl_withdraw.Visible = true;
            pnl_mainmenu.Visible = false;
            
            if (tb_withdraw.Text.Length > 0 && long.TryParse(tb_withdraw.Text, out _) && Convert.ToInt64(tb_withdraw.Text) > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row["Username"].ToString() == Name)
                    {
                        if (Convert.ToInt64(tb_withdraw.Text) <= Convert.ToInt64(row["Balance"]))
                        {
                            row["Balance"] = Convert.ToInt64(row["Balance"]) - Convert.ToInt64(tb_withdraw.Text);
                            ((List<string>)row["BalanceHis"]).Add("- " + tb_withdraw.Text);
                            //balanceReset();
                        }
                        else
                        {
                            MessageBox.Show("Withdrawal Amount Exceeds Limit.");
                        }
                    }
                }
            }
            else
            {
                if (tb_withdraw.Text.Length == 0 || !long.TryParse(tb_withdraw.Text, out long value) || Convert.ToInt64(tb_withdraw.Text) < 1)
                {
                    MessageBox.Show("Please Input Valid Amount");
                }
            }
            tb_withdraw.Clear();
        }
    }
}
