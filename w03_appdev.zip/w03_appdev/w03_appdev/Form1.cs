﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace w03_appdev
{
    public partial class Form1 : Form
    {
        DataTable Account = new DataTable();
        string username = string.Empty;
        string password = string.Empty;
        long saldo = 0;
        bool reset = false;

        public Form1(DataTable resett, bool reset)
        {
            InitializeComponent();
            btn_login.Enabled = false;
            if (reset)
            {
                reset = true;
            }
            if (reset == false)
            {
                Account.Columns.Add("Username", typeof(string));
                Account.Columns.Add("Password", typeof(string));
                Account.Columns.Add("Balance", typeof(long));
                Account.Columns.Add("Balance List", typeof(List<string>));
            }
            else
            {
                Account = resett;
            }
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            tb_username.Text = username;
            tb_password.Text = password;

            bool signup = false;
            bool error = false;
            string input = string.Empty;

            if (username.Length == 0)
            {
                error = true;
                MessageBox.Show("PLease input a valid username");
            }
            else if (password.Length == 0)
            {
                error = true;
                MessageBox.Show("PLease input a valid password");
            }

            foreach (DataRow row in Account.Rows)
            {
                if (row["Username"].ToString() == username)
                {
                    error = true;
                    MessageBox.Show("Username has already exist, please pick a different username");
                    tb_username.Clear();
                    tb_password.Clear();
                }
            }

            if (error == false)
            {
                signup = true;
                Account.Rows.Add(username, password, 0, new List<string>());
                MessageBox.Show("Registered successfully");
                btn_login.Enabled = true;
            }

            tb_username.Clear();
            tb_password.Clear();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            tb_username.Text = username;
            tb_password.Text = password;
            
            bool signin = true;
            bool error = false;
            string input = string.Empty;

            if (username.Length == 0)
            {
                error = true;
                MessageBox.Show("PLease input a vaid username");
            }
            else if (password.Length == 0)
            {
                error = true;
                MessageBox.Show("PLease input a vaid password");
            }
            
            foreach (DataRow row in Account.Rows)
            {
                if (row["Username"].ToString() == username)
                {
                    if (row["Password"].ToString() == password)
                    {
                        signin = true;
                        string username = row["Username"].ToString();
                        MessageBox.Show("Login Successfull");
                        Program program = new Program(username, password, saldo);
                        this.Hide();
                        program.ShowDialog();
                    }
                    else
                    {
                        signin = false;
                        MessageBox.Show("Username or password invalid");
                    }
                }
            }

            tb_username.Clear();
            tb_password.Clear();
        }
    }
}
