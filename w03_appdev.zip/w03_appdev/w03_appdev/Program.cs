﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace w03_appdev
{
    internal class Program : Form1
    {
        DataTable dt;
        string username;
        string password;
        long saldo;

        public Program(string username, string password, long saldo)
        {
            this.username = username;
            this.password = password;
            this.saldo = saldo;
        }

        public string usernamee()
        {
            return username;
        }

        public string passwordd()
        {
            return password;
        }
    }
}
